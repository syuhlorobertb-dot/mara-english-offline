# Mara–English Offline Translator (Android)

A beginner-friendly Android project using a local WebView interface and bundled JSON data. It does not request internet permission and the dictionary works offline.

## Included
- English → Mara and Mara → English search
- Bundled master translation records from `Mara_English_Translator_MERGED_Master_Database.xlsx`
- Reference worksheet data from that workbook, excluding the Mizo reference column
- No network permission; no online API required

## Build on GitHub Actions
1. Upload/extract this project so `settings.gradle`, `build.gradle`, and `app/` are at repository root.
2. Use JDK 17 and Android SDK.
3. Run `gradle assembleDebug`.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations of this first build
This is an offline dictionary/phrase search app, not a generative AI translator. It returns matching supplied records; it cannot reliably translate arbitrary unseen sentences. The master sheet's Mizo reference column is intentionally excluded.
