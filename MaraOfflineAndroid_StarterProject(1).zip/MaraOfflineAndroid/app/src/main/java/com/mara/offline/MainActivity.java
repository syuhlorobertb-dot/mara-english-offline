package com.mara.offline;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.text.TextUtils;

public class MainActivity extends Activity {
    private final String[][] entries = {
        {"I am going to Siaha.", "Siaha lâ ei sie aw."},
        {"Hi", "Samaw"},
        {"Hello", "Samaw"},
        {"What is your name?", "Na moh ahy maw?"},
        {"My name is Nana.", "Ei moh cha Nana a châ."},
        {"How are you?", "Na tlâh ma / Na pha ma?"},
        {"I am fine.", "Ei tlâh/pha nona a châ."},
        {"Thank you.", "Ei châ ly"},
        {"You're beautiful.", "Na hmipha kaw"},
        {"This is our house.", "He he eima O a châ."},
        {"What is this?", "He he khâpa maw?"},
        {"Where are you going?", "Khataihlâ na vawh aw / na sie aw?"},
        {"I'm going home.", "Ei di tua aw."},
        {"Where are you from?", "Khataihpa na châ?"},
        {"Cow", "Viahchao"},
        {"Dog", "I"},
        {"Cat", "Chhiezao"},
        {"Hen", "Awhpanô"},
        {"Rooster", "Awhkhypa"}
    };
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 36, 24, 24);
        root.setBackgroundColor(0xFFF7F5EF);
        TextView title = new TextView(this);
        title.setText("MARA–ENGLISH OFFLINE");
        title.setTextSize(23); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF254B3B);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Search your saved Mara words and sentences");
        sub.setTextSize(14); root.addView(sub);
        EditText query = new EditText(this);
        query.setSingleLine(true); query.setHint("Type English or Mara");
        root.addView(query);
        Button search = new Button(this); search.setText("Search");
        root.addView(search);
        TextView result = new TextView(this);
        result.setTextSize(18); result.setTextColor(0xFF222222);
        result.setPadding(0,24,0,0); root.addView(result);
        TextView note = new TextView(this);
        note.setText("Offline starter edition. If a phrase is not listed, it will say no exact match. More dictionary entries can be added.");
        note.setTextSize(12); note.setPadding(0,28,0,0); root.addView(note);
        search.setOnClickListener(v -> {
            String q = query.getText().toString().trim();
            if (q.isEmpty()) { result.setText("Please enter a word or sentence."); return; }
            StringBuilder out = new StringBuilder();
            for (String[] e : entries) {
                if (e[0].toLowerCase().contains(q.toLowerCase()) || e[1].toLowerCase().contains(q.toLowerCase())) {
                    out.append(e[0]).append("\n").append(e[1]).append("\n\n");
                }
            }
            result.setText(out.length() == 0 ? "No exact match in the starter dictionary yet." : out.toString());
        });
        setContentView(root);
    }
}
