Mara–English Offline Android starter app

This is a small offline phrase/dictionary prototype. It contains a limited starter sample, not the full Mara dictionary and not generative AI.

Build:
- Open this folder in Android Studio, or use the GitHub Actions workflow supplied separately.
- The workflow uses Gradle 8.9 and Android Gradle Plugin 8.7.3.
- Output: app/build/outputs/apk/debug/app-debug.apk
